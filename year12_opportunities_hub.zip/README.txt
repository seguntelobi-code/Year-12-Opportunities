YEAR 12 OPPORTUNITIES HUB

This is a QR-friendly, mobile-first webpage for your sixth form committee.

IMPORTANT:
A QR code needs a public web address. This package includes the website, but it is not
publicly hosted yet. Once you upload index.html to a web host (for example GitHub Pages),
use that public address as the QR destination.

EASIEST FREE SETUP — GITHUB PAGES
1. Create/sign into a GitHub account.
2. Create a new repository, e.g. "year12-opportunities".
3. Upload index.html.
4. In the repository, open Settings > Pages.
5. Choose deployment from the main branch/root and save.
6. GitHub will give you a public address ending in github.io.
7. Use that address for the QR code.

UPDATING:
Open index.html and edit only the DATA object near the bottom. Add/remove opportunities,
then upload the updated file. The QR code itself does NOT need to change as long as the
website address stays the same.

EVEN EASIER:
If you want to update opportunities without editing HTML, the next version can use a
Google Sheet as the database. You would edit the Sheet, and the website would update
automatically. That is the setup I recommend for a school committee because different
students can maintain it without touching code.

QR CODE:
The included QR code is a placeholder and intentionally does not point to a fake live
school website. Once you have your final public URL, regenerate the QR from that URL.
